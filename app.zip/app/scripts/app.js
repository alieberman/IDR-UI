'use strict';

/**
 * @ngdoc overview
 * @name idrApp
 * @description
 * # idrApp
 *
 * Main module of the application.
 */
angular
  .module('idrApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
	'mgcrea.ngStrap'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl'
      })
	  .when('/:id', {
        templateUrl: 'views/feedShow.html',
        controller: 'FeedShowCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });
  });
